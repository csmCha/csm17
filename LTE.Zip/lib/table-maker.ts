export type Gender = "female" | "male" | "other" | "no_answer";

export type Attendee = {
  id: string;
  nickname: string;
  gender: Gender;
  is_staff: boolean;
};

export type AssignedTable<T extends Attendee = Attendee> = { number: number; members: T[] };

const genderWeight: Record<Gender, number> = { female: 0, male: 1, other: 2, no_answer: 3 };

/** Creates balanced tables while spreading genders and assigning one staff member first. */
export function makeTables<T extends Attendee>(attendees: T[], peoplePerTable: number): AssignedTable<T>[] {
  const guests = attendees.filter((person) => !person.is_staff);
  const staff = attendees.filter((person) => person.is_staff);
  if (!guests.length) return [];

  // peoplePerTable is the number of guests; each resulting table gets one staff member when possible.
  const count = Math.ceil(guests.length / peoplePerTable);
  const tables = Array.from({ length: count }, (_, index) => ({ number: index + 1, members: [] as T[] }));

  // Spread staff evenly. Extra staff are treated like normal attendees below.
  staff.slice(0, count).forEach((person, index) => tables[index].members.push(person));
  const remaining = [...staff.slice(count), ...guests];
  const genderGroups = new Map<Gender, T[]>();
  remaining.forEach((person) => genderGroups.set(person.gender, [...(genderGroups.get(person.gender) ?? []), person]));

  // Largest gender group first; placing in the least-represented table minimizes concentration.
  [...genderGroups.entries()]
    .sort((a, b) => b[1].length - a[1].length)
    .forEach(([gender, people]) => {
      people.sort((a, b) => a.nickname.localeCompare(b.nickname));
      people.forEach((person) => {
        const target = [...tables].sort((a, b) => {
          const aSame = a.members.filter((member) => member.gender === gender).length;
          const bSame = b.members.filter((member) => member.gender === gender).length;
          return aSame - bSame || a.members.length - b.members.length || a.number - b.number;
        })[0];
        target.members.push(person);
      });
    });

  return tables.map((table) => ({
    ...table,
    members: [...table.members].sort((a, b) => Number(b.is_staff) - Number(a.is_staff) || genderWeight[a.gender] - genderWeight[b.gender]),
  }));
}
