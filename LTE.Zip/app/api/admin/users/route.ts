import { createClient } from "@supabase/supabase-js";
import { NextRequest, NextResponse } from "next/server";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

async function requireSuperAdmin(request: NextRequest) {
  if (!url || !serviceKey) return null;
  const token = request.headers.get("authorization")?.replace("Bearer ", "");
  if (!token) return null;
  const admin = createClient(url, serviceKey);
  const { data: userData } = await admin.auth.getUser(token);
  if (!userData.user) return null;
  const { data: profile } = await admin.from("profiles").select("role").eq("id", userData.user.id).single();
  return profile?.role === "super_admin" ? admin : null;
}

export async function POST(request: NextRequest) {
  const admin = await requireSuperAdmin(request);
  if (!admin) return NextResponse.json({ error: "권한이 없거나 서버 설정이 누락됐습니다." }, { status: 403 });
  const { email, role } = await request.json();
  if (!email || !["staff", "super_admin"].includes(role)) return NextResponse.json({ error: "초대 정보를 확인해 주세요." }, { status: 400 });
  const { data, error } = await admin.auth.admin.inviteUserByEmail(email);
  if (error || !data.user) return NextResponse.json({ error: error?.message ?? "초대를 보내지 못했습니다." }, { status: 400 });
  await admin.from("profiles").upsert({ id: data.user.id, email, role });
  return NextResponse.json({ user: { id: data.user.id, email, role } });
}
