import { createClient } from "@supabase/supabase-js";
import { NextRequest, NextResponse } from "next/server";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!url || !serviceKey) return NextResponse.json({ error: "서버 설정이 누락됐습니다." }, { status: 500 });
  const token = request.headers.get("authorization")?.replace("Bearer ", "");
  const admin = createClient(url, serviceKey);
  const { data: userData } = await admin.auth.getUser(token);
  if (!userData.user) return NextResponse.json({ error: "로그인이 필요합니다." }, { status: 401 });
  const { data: profile } = await admin.from("profiles").select("role").eq("id", userData.user.id).single();
  const { id } = await params;
  if (profile?.role !== "super_admin" || id === userData.user.id) return NextResponse.json({ error: "이 계정은 삭제할 수 없습니다." }, { status: 403 });
  const { error } = await admin.auth.admin.deleteUser(id);
  if (error) return NextResponse.json({ error: "계정을 삭제하지 못했습니다." }, { status: 400 });
  return NextResponse.json({ ok: true });
}
