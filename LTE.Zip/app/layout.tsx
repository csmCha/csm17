import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "LTE Table Maker",
  description: "Let’s Talk in English table assignments",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}
