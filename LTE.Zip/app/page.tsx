"use client";

import { FormEvent, useEffect, useState } from "react";
import { isSupabaseConfigured, supabase } from "../lib/supabase";
import { Gender } from "../lib/table-maker";

type Meetup = { id: string; title: string; event_date: string; start_time?: string | null; location?: string | null; max_guests?: number | null; signup_deadline?: string | null; status: "open" | "closed" | "published"; people_per_table: number };
type Participant = { id: string; nickname: string; gender: Gender; event_id: string };
const initialMeetup: Meetup = { id: "demo", title: "LTE Friday Meetup", event_date: "2026-08-07", start_time: "19:00", location: "Seoul", max_guests: 30, status: "open", people_per_table: 4 };

export default function Home() {
  const [meetup, setMeetup] = useState<Meetup>(initialMeetup);
  const [count, setCount] = useState(0);
  const [nickname, setNickname] = useState("");
  const [gender, setGender] = useState<Gender>("female");
  const [notice, setNotice] = useState("");

  useEffect(() => { void loadMeetup(); }, []);
  async function loadMeetup() {
    if (!supabase) return;
    const { data: rows } = await supabase.from("events").select("*").eq("status", "open").order("event_date").limit(1);
    if (!rows?.[0]) return;
    setMeetup(rows[0]);
    const { data: participantCount } = await supabase.rpc("get_event_guest_count", { target_event: rows[0].id });
    setCount(participantCount ?? 0);
  }
  async function join(form: FormEvent) {
    form.preventDefault();
    const cleanName = nickname.trim(); if (!cleanName) return;
    const participant: Participant = { id: crypto.randomUUID(), nickname: cleanName, gender, event_id: meetup.id };
    if (supabase) {
      const { error } = await supabase.from("participants").insert({ event_id: meetup.id, nickname: cleanName, gender, is_staff: false });
      if (error) { setNotice("신청을 저장하지 못했어요. 잠시 후 다시 시도해 주세요."); return; }
    }
    setCount((current) => current + 1); setNickname(""); setNotice(`${participant.nickname}님, 신청이 완료됐어요!`);
  }
  return <main>
    <header className="topbar"><a className="brand" href="#top">LTE <span>TABLE MAKER</span></a><a className="admin-link" href="/admin">운영진 로그인 <span>→</span></a></header>
    <section id="top" className="hero"><div><p className="eyebrow">LET’S TALK IN ENGLISH</p><h1>좋은 대화는<br /><em>좋은 테이블</em>에서.</h1><p className="subcopy">매주 더 다양한 사람들과, 더 편하게 영어로 이야기하세요.</p></div><div className="hero-orb"><b>{count}</b><span>JOINED<br />THIS WEEK</span></div></section>
    {!isSupabaseConfigured && <div className="setup">데모 모드입니다. Supabase를 연결하면 매주 참가 기록과 테이블 배정이 안전하게 저장됩니다.</div>}
    {notice && <div className="notice">{notice}<button onClick={() => setNotice("")}>×</button></div>}
    <section className="join-layout"><div className="meetup-card"><div className="date-badge"><span>{meetup.event_date.slice(5).replace("-", ".")}</span><small>MEETUP</small></div><div><p className="eyebrow">NOW OPEN</p><h2>{meetup.title}</h2><p>{meetup.event_date} · {meetup.start_time?.slice(0, 5) ?? "시간 미정"}</p><p>{meetup.location ?? "장소 미정"} · 테이블당 4–6명</p></div><div className="availability"><b>{count}{meetup.max_guests ? ` / ${meetup.max_guests}` : ""}</b><span>명 신청</span></div></div><section className="card join"><p className="eyebrow">JOIN THE CONVERSATION</p><h2>이번 주, 함께할까요?</h2><p>닉네임과 성별을 알려주시면 균형 있는 테이블로 안내할게요.</p><form onSubmit={join}><label>닉네임<input value={nickname} onChange={(e) => setNickname(e.target.value)} maxLength={20} placeholder="예: Sunny" required /></label><label>성별<select value={gender} onChange={(e) => setGender(e.target.value as Gender)}><option value="female">여성</option><option value="male">남성</option><option value="other">기타</option><option value="no_answer">응답하지 않음</option></select></label><button className="primary" disabled={meetup.status !== "open" || Boolean(meetup.max_guests && count >= meetup.max_guests)}>참가 신청하기 <span>→</span></button></form></section></section>
  </main>;
}
